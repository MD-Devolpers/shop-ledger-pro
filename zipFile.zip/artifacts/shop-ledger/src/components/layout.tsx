import { Link, useLocation } from "wouter";
import {
  Home,
  ListOrdered,
  Users,
  TrendingUp,
  BarChart3,
  Settings,
  DatabaseBackup,
  LogOut,
  ScrollText,
  Trash2,
  Wallet,
  Banknote,
  Smartphone,
  FileBarChart2,
  MoreHorizontal,
  X,
  Package,
  ShoppingCart,
  RotateCcw,
  FileBarChart,
  Building2,
  Store,
  PackageX,
  PackagePlus,
  ClipboardList,
  ShieldCheck,
  Star,
  Cpu,
} from "lucide-react";
import { useGetMe, useLogout, useGetReportSummary } from "@workspace/api-client-react";
import { SyncStatus, OfflineBanner } from "@/components/sync-status";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

const bottomNavItems = [
  { icon: Home, label: "Home", href: "/app" },
  { icon: ListOrdered, label: "Entries", href: "/entries" },
  { icon: Users, label: "Credits", href: "/credits" },
  { icon: BarChart3, label: "Reports", href: "/reports" },
];

const moreItems = [
  { icon: TrendingUp, label: "Profits", href: "/profits" },
  { icon: Wallet, label: "Closing", href: "/closing" },
  { icon: FileBarChart2, label: "Digital Report", href: "/digital-report" },
  { icon: Package, label: "Inventory", href: "/inventory" },
  { icon: Star, label: "Quick Products", href: "/inventory/quick-products" },
  { icon: FileBarChart, label: "Prod. Reports", href: "/inventory/product-reports" },
  { icon: PackageX, label: "Replacements", href: "/inventory/company-replacements" },
  { icon: Banknote, label: "Supplier Credit", href: "/inventory/supplier-balance" },
  { icon: ShieldCheck, label: "Warranty Check", href: "/inventory/warranty-check" },
  { icon: Cpu, label: "Mobile Purchase", href: "/inventory/mobile-purchase" },
  { icon: Trash2, label: "Recycle Bin", href: "/recycle-bin" },
  { icon: DatabaseBackup, label: "Backup", href: "/backup" },
  { icon: Settings, label: "Settings", href: "/settings" },
];

const sidebarNavItems = [
  { icon: Home, label: "Home", href: "/app" },
  { icon: ListOrdered, label: "Entries", href: "/entries" },
  { icon: Users, label: "Credits", href: "/credits" },
  { icon: TrendingUp, label: "Profits", href: "/profits" },
  { icon: BarChart3, label: "Reports", href: "/reports" },
  { icon: Wallet, label: "Closing", href: "/closing" },
  { icon: FileBarChart2, label: "Digital Report", href: "/digital-report" },
];

const inventoryNavItems = [
  { icon: Package, label: "Inventory", href: "/inventory" },
  { icon: ListOrdered, label: "Products", href: "/inventory/products" },
  { icon: ClipboardList, label: "Purchase Report", href: "/inventory/purchase-bills" },
  { icon: Star, label: "Quick Products", href: "/inventory/quick-products" },
  { icon: FileBarChart, label: "Product Reports", href: "/inventory/product-reports" },
  { icon: PackageX, label: "Replacements", href: "/inventory/company-replacements" },
  { icon: Banknote, label: "Supplier Credit", href: "/inventory/supplier-balance" },
  { icon: Cpu, label: "Mobile Purchase", href: "/inventory/mobile-purchase" },
  { icon: Building2, label: "Masters", href: "/inventory/masters" },
  { icon: Store, label: "Bill Settings", href: "/inventory/bill-settings" },
  { icon: ShieldCheck, label: "Warranty Check", href: "/inventory/warranty-check" },
];

const secondaryNavItems = [
  { icon: Trash2, label: "Recycle Bin", href: "/recycle-bin" },
  { icon: DatabaseBackup, label: "Backup", href: "/backup" },
  { icon: Settings, label: "Settings", href: "/settings" },
];

function formatCurrencyShort(amount: number) {
  if (Math.abs(amount) >= 100000) {
    return `Rs ${(amount / 1000).toFixed(0)}K`;
  }
  return new Intl.NumberFormat("en-PK", {
    style: "currency",
    currency: "PKR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function Layout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const { data: user } = useGetMe();
  const logout = useLogout();
  const { toast } = useToast();
  const { data: summary } = useGetReportSummary();
  const [moreOpen, setMoreOpen] = useState(false);

  const handleLogout = () => {
    logout.mutate(undefined, {
      onSuccess: () => setLocation("/"),
      onError: (error) => {
        toast({
          title: "Logout failed",
          description: error.error || "An unexpected error occurred",
          variant: "destructive",
        });
      },
    });
  };

  const isActive = (href: string) =>
    location === href || (href.length > 4 && location.startsWith(href));

  const isMoreActive = moreItems.some((item) => isActive(item.href));

  const SidebarNavLinks = ({
    items,
    onClick,
  }: {
    items: typeof sidebarNavItems;
    onClick?: () => void;
  }) => (
    <div className="flex flex-col space-y-1">
      {items.map((item) => {
        const active = isActive(item.href);
        return (
          <Link key={item.href} href={item.href}>
            <Button
              variant={active ? "secondary" : "ghost"}
              className={`w-full justify-start ${active ? "font-semibold" : "font-normal text-muted-foreground"}`}
              onClick={onClick}
              data-testid={`nav-${item.label.toLowerCase()}`}
            >
              <item.icon className={`mr-3 h-5 w-5 ${active ? "text-primary" : ""}`} />
              {item.label}
            </Button>
          </Link>
        );
      })}
    </div>
  );

  const LogoMark = () => (
    <div className="flex items-center gap-2">
      <img src="/logo.png?v=2" alt="Ledger Entries" className="w-44 h-auto object-contain" />
    </div>
  );

  const BalanceChips = () => (
    <div className="flex items-center gap-1.5">
      <div className="flex items-center gap-1 bg-green-100 text-green-800 rounded-full px-2 py-0.5 text-[11px] font-semibold">
        <Banknote className="h-3 w-3" />
        {summary ? formatCurrencyShort(summary.cashBalance) : "—"}
      </div>
      <div className="flex items-center gap-1 bg-blue-100 text-blue-800 rounded-full px-2 py-0.5 text-[11px] font-semibold">
        <Smartphone className="h-3 w-3" />
        {summary ? formatCurrencyShort(summary.digitalBalance) : "—"}
      </div>
    </div>
  );

  return (
    <div className="min-h-[100dvh] flex flex-col md:flex-row bg-background">
      {/* ── Mobile Header ── */}
      <header className="md:hidden flex flex-col border-b bg-card sticky top-0 z-10">
        <div className="flex items-center justify-between px-4 py-3">
          <LogoMark />
          <div className="flex items-center gap-2">
            <SyncStatus />
            <BalanceChips />
          </div>
        </div>
        <OfflineBanner />
      </header>

      {/* ── Desktop Sidebar ── */}
      <aside className="hidden md:flex flex-col w-64 border-r bg-card sticky top-0 h-screen">
        <div className="px-5 py-4 flex items-center">
          <img src="/logo.png?v=2" alt="Ledger Entries" className="w-60 h-auto object-contain" />
        </div>

        {summary && (
          <div className="mx-4 mb-2 bg-muted/50 rounded-xl p-3 border">
            <div className="grid grid-cols-2 gap-1 text-center">
              <div>
                <div className="flex items-center justify-center gap-1 text-green-700 mb-0.5">
                  <Banknote className="h-3 w-3" />
                  <span className="text-[10px] font-medium">Cash</span>
                </div>
                <p className="text-xs font-bold text-green-700">{formatCurrencyShort(summary.cashBalance)}</p>
              </div>
              <div>
                <div className="flex items-center justify-center gap-1 text-blue-700 mb-0.5">
                  <Smartphone className="h-3 w-3" />
                  <span className="text-[10px] font-medium">Digital</span>
                </div>
                <p className="text-xs font-bold text-blue-700">{formatCurrencyShort(summary.digitalBalance)}</p>
              </div>
            </div>
          </div>
        )}

        <div className="flex-1 overflow-y-auto py-4 px-4 flex flex-col gap-2">
          <SidebarNavLinks items={sidebarNavItems} />
          <div className="h-px bg-border my-2" />
          <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground px-2 mb-1">Inventory</p>
          <SidebarNavLinks items={inventoryNavItems} />
          <div className="h-px bg-border my-2" />
          <SidebarNavLinks items={secondaryNavItems} />
        </div>

        {user && (
          <div className="p-4 border-t bg-muted/20 flex items-center justify-between">
            <div className="flex items-center gap-3 overflow-hidden">
              <Avatar className="h-10 w-10 border border-primary/20">
                <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                  {user.username.substring(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex flex-col overflow-hidden">
                <span className="text-sm font-medium truncate">{user.username}</span>
                <span className="text-xs text-muted-foreground">
                  {(user as any)?.role === "admin" ? "Admin" : "Shop Owner"}
                </span>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={handleLogout} data-testid="button-logout-desktop">
              <LogOut className="h-5 w-5 text-muted-foreground" />
            </Button>
          </div>
        )}
      </aside>

      {/* ── Main Content ── */}
      <main className="flex-1 flex flex-col min-w-0 bg-background md:bg-muted/10 pb-[64px] md:pb-0">
        {children}
      </main>

      {/* ── Mobile Bottom Nav ── */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-20 border-t bg-card flex items-center justify-around px-2 pt-2 pb-safe">
        {bottomNavItems.map((item) => {
          const active = isActive(item.href);
          return (
            <Link key={item.href} href={item.href}>
              <div
                className={`flex flex-col items-center justify-center p-1.5 min-w-[56px] ${active ? "text-primary" : "text-muted-foreground"}`}
                data-testid={`bottom-nav-${item.label.toLowerCase()}`}
              >
                <div className={`mb-0.5 p-1 rounded-full ${active ? "bg-primary/10" : ""}`}>
                  <item.icon className="h-5 w-5" strokeWidth={active ? 2.5 : 2} />
                </div>
                <span className="text-[9px] font-medium">{item.label}</span>
              </div>
            </Link>
          );
        })}

        {/* More tab */}
        <button
          onClick={() => setMoreOpen(true)}
          className={`flex flex-col items-center justify-center p-1.5 min-w-[56px] ${isMoreActive ? "text-primary" : "text-muted-foreground"}`}
          data-testid="bottom-nav-more"
        >
          <div className={`mb-0.5 p-1 rounded-full ${isMoreActive ? "bg-primary/10" : ""}`}>
            <MoreHorizontal className="h-5 w-5" strokeWidth={isMoreActive ? 2.5 : 2} />
          </div>
          <span className="text-[9px] font-medium">More</span>
        </button>
      </nav>

      {/* ── Mobile More Bottom Sheet ── */}
      {moreOpen && (
        <>
          {/* Backdrop */}
          <div
            className="md:hidden fixed inset-0 z-30 bg-black/40"
            onClick={() => setMoreOpen(false)}
          />
          {/* Sheet */}
          <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-card rounded-t-2xl shadow-2xl border-t">
            {/* Handle */}
            <div className="flex justify-center pt-3 pb-1">
              <div className="w-10 h-1 rounded-full bg-muted-foreground/30" />
            </div>

            {/* User info */}
            {user && (
              <div className="px-4 pt-2 pb-3 flex items-center justify-between border-b">
                <div className="flex items-center gap-3">
                  <Avatar className="h-9 w-9">
                    <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                      {user.username.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-semibold">{user.username}</p>
                    <p className="text-xs text-muted-foreground">
                      {(user as any)?.role === "admin" ? "Admin" : "Shop Owner"}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setMoreOpen(false)}
                  className="h-8 w-8 rounded-full bg-muted flex items-center justify-center"
                >
                  <X className="h-4 w-4 text-muted-foreground" />
                </button>
              </div>
            )}

            {/* Nav items grid */}
            <div className="grid grid-cols-3 gap-1 p-4">
              {moreItems.map((item) => {
                const active = isActive(item.href);
                return (
                  <Link key={item.href} href={item.href}>
                    <div
                      onClick={() => setMoreOpen(false)}
                      className={`flex flex-col items-center justify-center gap-1.5 p-3 rounded-xl transition-colors ${
                        active
                          ? "bg-primary/10 text-primary"
                          : "bg-muted/50 text-foreground hover:bg-muted"
                      }`}
                    >
                      <item.icon className="h-5 w-5" strokeWidth={active ? 2.5 : 2} />
                      <span className="text-[10px] font-medium text-center leading-tight">
                        {item.label}
                      </span>
                    </div>
                  </Link>
                );
              })}
            </div>

            {/* Logout */}
            <div className="px-4 pb-6">
              <button
                onClick={handleLogout}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-red-50 text-red-600 text-sm font-medium"
              >
                <LogOut className="h-4 w-4" />
                Logout
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
